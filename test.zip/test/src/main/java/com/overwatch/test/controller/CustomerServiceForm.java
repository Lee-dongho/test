package com.overwatch.test.controller;

import lombok.Getter;
import lombok.Setter;

@Setter @Getter
public class CustomerServiceForm {

    private String Name;
    private String Email;
    private String Subject;
    private String Message;

}
